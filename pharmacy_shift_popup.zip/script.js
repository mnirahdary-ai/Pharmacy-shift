let reports=[];
const CLINICAL_BADGES=['78482','5874336'];
const ADMIN_BADGES=['1001011','1004127'];
const DIRECTOR_BADGES=['9141896'];

function init(){
  const saved=localStorage.getItem('pharmacyShiftReports');
  reports=saved?JSON.parse(saved):[];
  sortReports();
  updateClock();
  setInterval(updateClock,1000);
}
function updateClock(){document.getElementById('clock').innerText=new Date().toLocaleString();}
function sortReports(){reports.sort((a,b)=>new Date(b.dateISO)-new Date(a.dateISO));}
function getBadgeClass(badge){
  if(CLINICAL_BADGES.includes(badge))return'badge-clinical';
  if(ADMIN_BADGES.includes(badge))return'badge-admin';
  if(DIRECTOR_BADGES.includes(badge))return'badge-director';
  return'';
}
function getSpecialCardClass(badge,sendTo){
  if(sendTo)return'forwarded-card';
  if(CLINICAL_BADGES.includes(badge))return'special-card-clinical';
  if(ADMIN_BADGES.includes(badge))return'special-card-admin';
  if(DIRECTOR_BADGES.includes(badge))return'special-card-director';
  return'';
}
function showPage(page){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  if(page==='home')document.getElementById('homePage').classList.add('active');
  else if(page==='addReport')document.getElementById('addReportPage').classList.add('active');
  else if(page==='latestReports'){document.getElementById('latestReportsPage').classList.add('active');displayLatestReports();}
  else if(page==='viewReports'){document.getElementById('viewReportsPage').classList.add('active');displayAllReports();}
}
document.getElementById('reportForm').addEventListener('submit',function(e){
  e.preventDefault();
  const newReport={id:Date.now(),dateISO:new Date().toISOString(),
    employeeName:document.getElementById('employeeName').value.trim(),
    badgeNumber:document.getElementById('badgeNumber').value.trim(),
    section:document.getElementById('section').value,
    shift:document.getElementById('shift').value,
    sendTo:document.getElementById('sendToSection').value,
    content:document.getElementById('reportContent').value.trim()};
  reports.push(newReport);
  if(newReport.sendTo){ // duplicate for sendTo section
    let clone={...newReport,section:newReport.sendTo,originalSection:newReport.section};
    reports.push(clone);
  }
  sortReports();
  localStorage.setItem('pharmacyShiftReports',JSON.stringify(reports));
  document.getElementById('alertContainer').innerHTML='<div>Report saved successfully!</div>';
  setTimeout(()=>document.getElementById('alertContainer').innerHTML='',2000);
  this.reset();setTimeout(()=>showPage('latestReports'),1000);
});
function displayLatestReports(){
  const container=document.getElementById('latestReportsList');
  const sections=['Inpatient Pharmacy','Outpatient Pharmacy','Clinical Services','Material Management','OR Pharmacy','ER Pharmacy','IV','Other'];
  if(reports.length===0){container.innerHTML='<p>No reports yet</p>';return;}
  let html='';
  sections.forEach(sect=>{
    const sectReports=reports.filter(r=>r.section===sect).slice(0,1); // show latest one inline
    html+=`<div class="report-item"><h3>${sect}</h3>`;
    if(sectReports.length){
      const latest=sectReports[0];
      if(latest.sendTo || latest.originalSection){
        html+=`<div class="forwarded-note">Forwarded from ${latest.originalSection||latest.section}</div>`;
      }
      html+=`<button onclick="openModal('${sect}')">Show Reports</button>`;
    } else {html+='<div>No reports yet</div>';}
    html+='</div>';
  });
  container.innerHTML=html;
}
function openModal(section){
  document.getElementById('reportsModal').style.display='block';
  document.getElementById('modalSectionTitle').innerText=section+" - Recent Reports";
  const container=document.getElementById('modalReportsList');
  const sectReports=reports.filter(r=>r.section===section).slice(0,10);
  let html='';
  sectReports.forEach(report=>{
    const date=new Date(report.dateISO);
    const badgeClass=getBadgeClass(report.badgeNumber);
    html+=`<div class="report-item ${getSpecialCardClass(report.badgeNumber,report.sendTo||report.originalSection)}">`;
    if(report.sendTo||report.originalSection){html+=`<div class="forwarded-note">Forwarded from ${report.originalSection||report.section}</div>`;}
    html+=`<div><b>Date:</b> ${date.toLocaleDateString()} ${date.toLocaleTimeString()}</div>`;
    html+=`<div><b>Employee:</b> ${report.employeeName}</div>`;
    html+=`<div><b>Badge:</b> <span class="badge-highlight ${badgeClass}">${report.badgeNumber}</span></div>`;
    html+=`<div><b>Shift:</b> ${report.shift||''}</div>`;
    html+=`<div>${report.content}</div>`;
    if(report.sendTo){html+=`<div><b>Sent to Section:</b> ${report.sendTo}</div>`;}
    html+='</div>';
  });
  container.innerHTML=html;
}
function closeModal(){document.getElementById('reportsModal').style.display='none';}
function displayAllReports(){
  const container=document.getElementById('allReportsList');
  if(reports.length===0){container.innerHTML='<p>No reports found</p>';return;}
  let html='';
  reports.forEach(report=>{
    const date=new Date(report.dateISO);
    const badgeClass=getBadgeClass(report.badgeNumber);
    html+=`<div class="report-item ${getSpecialCardClass(report.badgeNumber,report.sendTo||report.originalSection)}"><h3>${report.section}</h3>`;
    if(report.sendTo||report.originalSection){html+=`<div class="forwarded-note">Forwarded from ${report.originalSection||report.section}</div>`;}
    html+=`<div><b>Date:</b> ${date.toLocaleDateString()} ${date.toLocaleTimeString()}</div>`;
    html+=`<div><b>Employee:</b> ${report.employeeName}</div>`;
    html+=`<div><b>Badge:</b> <span class="badge-highlight ${badgeClass}">${report.badgeNumber}</span></div>`;
    html+=`<div><b>Shift:</b> ${report.shift||''}</div>`;
    html+=`<div>${report.content}</div>`;
    if(report.sendTo){html+=`<div><b>Sent to Section:</b> ${report.sendTo}</div>`;}
    html+='</div>';
  });
  container.innerHTML=html;
}
function filterReports(){displayAllReports();}
function exportToCSV(){
  if(reports.length===0){alert('No reports');return;}
  let csv='Date,Employee,Badge,Section,Shift,Content,SendTo\n';
  reports.forEach(r=>{csv+=`${r.dateISO},${r.employeeName},${r.badgeNumber},${r.section},${r.shift},${r.content},${r.sendTo}\n`;});
  const blob=new Blob([csv],{type:'text/csv'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url;a.download='reports.csv';a.click();URL.revokeObjectURL(url);
}
init();
